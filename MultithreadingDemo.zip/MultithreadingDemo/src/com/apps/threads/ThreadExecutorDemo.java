package com.apps.threads;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

class CallableProcessor implements Callable<Integer> {
	private Integer number;

	public CallableProcessor(Integer number) {
		this.number = number;
	}

	@Override
	public Integer call() throws Exception {
		int sum = 0;
		for (int i = 0; i < number; i++) {
			sum = sum + i;
			TimeUnit.MILLISECONDS.sleep(20);
		}
		return sum;
	}

}

public class ThreadExecutorDemo {
	public static void main(String[] args) {
		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors
				.newFixedThreadPool(1);

		List<Future<Integer>> resultList = new ArrayList<>();

		Random random = new Random();

		for (int i = 0; i < 4; i++) {
			Integer number = random.nextInt(5);
			CallableProcessor callableProcessor = new CallableProcessor(number);
			Future<Integer> future = executor.submit(callableProcessor);
			resultList.add(future);
		}
		for (Future<Integer> future : resultList) {
			try {
				System.out.println(future.get());
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
		}
		executor.shutdown();
	}
}
