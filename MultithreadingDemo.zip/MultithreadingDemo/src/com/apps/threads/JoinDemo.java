package com.apps.threads;
/*class JoinTest extends Thread{
	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println("Sita thread");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}*/
class A{
	void disp(String a){
		System.out.println("Strig");
	}
	void disp(Object a){
		System.out.println("Object");
	}
	
}
public class JoinDemo {

	public static void main(String[] args) {
		/*JoinTest jt=new JoinTest();
		jt.start();
		try {
			jt.join(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < 5; i++) {
			System.out.println("Ram thread");
		}*/
		
		A a =new A();
		a.disp(null);
	}

}
