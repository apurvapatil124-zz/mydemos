package com.apps.threads;

class YeildTest extends Thread{
	public void run(){
		for (int i = 0; i < 10; i++) {
			System.out.println("Child thread");
			Thread.yield();
		}
		
	}
}
public class YieldDemo {

	public static void main(String[] args) {
		YeildTest yt=new YeildTest();
		
		for (int i = 0; i < 10; i++) {
			System.out.println("Main thread");
			
		}
		yt.start();
	}

}
